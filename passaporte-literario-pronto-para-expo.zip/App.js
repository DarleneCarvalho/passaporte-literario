import React, { useState } from 'react';
import { View, Text, TextInput, Button, FlatList, StyleSheet, ScrollView, TouchableOpacity, Alert, Image } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

export default function App() {
  const [livros, setLivros] = useState([]);
  const [titulo, setTitulo] = useState('');
  const [avaliacao, setAvaliacao] = useState('');
  const [resumo, setResumo] = useState('');
  const [capaUrl, setCapaUrl] = useState('');

  const adicionarLivro = () => {
    if (titulo.trim() === '') return;

    const novoLivro = {
      id: Date.now().toString(),
      titulo,
      avaliacao,
      resumo,
      capaUrl,
    };

    setLivros([novoLivro, ...livros]);
    setTitulo('');
    setAvaliacao('');
    setResumo('');
    setCapaUrl('');
  };

  const removerLivro = (id) => {
    Alert.alert(
      "Remover livro",
      "Tem certeza que deseja remover este livro?",
      [
        { text: "Cancelar", style: "cancel" },
        {
          text: "Remover",
          style: "destructive",
          onPress: () => {
            const novaLista = livros.filter((livro) => livro.id !== id);
            setLivros(novaLista);
          }
        }
      ]
    );
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>Passaporte Literário</Text>

      <TextInput
        style={styles.input}
        placeholder="Título do livro"
        value={titulo}
        onChangeText={setTitulo}
      />

      <TextInput
        style={styles.input}
        placeholder="Avaliação (ex: 4/5 ou comentário)"
        value={avaliacao}
        onChangeText={setAvaliacao}
      />

      <TextInput
        style={[styles.input, { height: 80 }]}
        placeholder="Resumo breve"
        multiline
        value={resumo}
        onChangeText={setResumo}
      />

      <TextInput
        style={styles.input}
        placeholder="URL da capa do livro (link da imagem)"
        value={capaUrl}
        onChangeText={setCapaUrl}
      />

      <Button title="Adicionar livro" onPress={adicionarLivro} />

      <FlatList
        data={livros}
        keyExtractor={(item) => item.id}
        style={{ marginTop: 20 }}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => removerLivro(item.id)} style={styles.livroItem}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              {item.capaUrl ? (
                <Image source={{ uri: item.capaUrl }} style={styles.capa} />
              ) : (
                <View style={[styles.capa, styles.capaPlaceholder]}>
                  <Text style={{ color: '#888', fontSize: 12 }}>Sem capa</Text>
                </View>
              )}
              <View style={{ flex: 1, marginLeft: 10 }}>
                <Text style={styles.livroTitulo}>{item.titulo}</Text>
                <Text>Avaliação: {item.avaliacao}</Text>
                <Text>Resumo: {item.resumo}</Text>
                <Text style={styles.removerTexto}>Toque para remover</Text>
              </View>
            </View>
          </TouchableOpacity>
        )}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, marginTop: 40, backgroundColor: '#fff' },
  header: { fontSize: 24, fontWeight: 'bold', marginBottom: 20, textAlign: 'center', color: '#4B0082' },
  input: { borderWidth: 1, borderColor: '#ccc', padding: 10, marginBottom: 10, borderRadius: 5 },
  livroItem: { marginBottom: 15, padding: 10, backgroundColor: '#f0f0f0', borderRadius: 5 },
  livroTitulo: { fontWeight: 'bold', fontSize: 16 },
  removerTexto: { marginTop: 5, fontSize: 12, color: 'red' },
  capa: { width: 60, height: 90, borderRadius: 5, backgroundColor: '#ddd' },
  capaPlaceholder: { justifyContent: 'center', alignItems: 'center' },
});